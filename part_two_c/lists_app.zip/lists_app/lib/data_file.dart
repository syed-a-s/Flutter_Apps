class MiscOrgs {
  String orgName;
  String orgURL;

  // constructor
  MiscOrgs(this.orgName, this.orgURL);
}

List<MiscOrgs> orgs = [
  MiscOrgs('Youtube', 'https://www.youtube.com'),
  MiscOrgs('Reddit', 'https://www.reddit.com'),
  MiscOrgs('Twitter', 'https://www.twitter.com'),
  MiscOrgs('Google', 'https://www.google.edu'),
];